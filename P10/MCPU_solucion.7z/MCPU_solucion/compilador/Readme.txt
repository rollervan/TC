------------------------------------------
Compilar un programa en ensamblador:
· Abrir un CMD
· Ejecutar> smal counter.asm

Se generará counter.o, que contiene el contenido en hex de la memoria sram de MCPU

------------------------------------------
Simular el código objeto:
· En el CMD ejecutar> cpu3emu counter.o

Con las flechas del teclado nos movemos
Con la barra espaciadora ejecutamos el código
Con la tecla S ejecutamos instrucción a instrucción
Con la tecla R reseteamos el programa
------------------------------------------